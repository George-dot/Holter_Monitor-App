package com.holter.holtermonitor.ui;

import androidx.annotation.IdRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.holter.holtermonitor.R;

public abstract class BaseActivity extends AppCompatActivity implements NavigationBarView.OnItemSelectedListener {
    private static final String TAG = BaseActivity.class.getSimpleName();
    protected BottomNavigationView mBottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getContentViewId());

        mBottomNavigationView = findViewById(R.id.bottom_navigation);
        mBottomNavigationView.setOnItemSelectedListener(this);
        init();

    }

    public BottomNavigationView getBottomNav() {
        return mBottomNavigationView;
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateNavigationBarState();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull final MenuItem item) {

        try {
            int itemId = item.getItemId();

            if (itemId == R.id.item_dashboard) {
                Intent intent = new Intent(BaseActivity.this, DashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            } else if (itemId == R.id.item_history) {
                Intent activityIntent = new Intent(BaseActivity.this, HistoryActivity.class);
                activityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(activityIntent);
            } else if (itemId == R.id.item_settings) {
                Intent i = new Intent(BaseActivity.this, SettingsActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
            }

        } catch (Exception e) {
            Log.d(TAG, e.getMessage(), e);
        }


        return true;
    }

    private void updateNavigationBarState() {
        int actionId = getNavigationMenuItemId();
        selectBottomNavigationBarItem(actionId);
    }

    void selectBottomNavigationBarItem(int itemId) {
        Menu menu = mBottomNavigationView.getMenu();
        for (int i = 0, size = menu.size(); i < size; i++) {
            MenuItem item = menu.getItem(i);
            boolean shouldBeChecked = item.getItemId() == itemId;
            if (shouldBeChecked) {
                item.setChecked(true);
                break;
            }
        }
    }

    @LayoutRes
    abstract int getContentViewId();

    @IdRes
    abstract int getNavigationMenuItemId();

    abstract void init();

}