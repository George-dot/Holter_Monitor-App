package com.holter.holtermonitor.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.holter.holtermonitor.R;
import com.holter.holtermonitor.utils.HolterMonitorConstants;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText mEditTextEmail;
    private TextInputLayout mTextInputEmail;
    private TextInputEditText mEditTextPassword;
    private TextInputLayout mTextInputPassword;
    private Toolbar mToolbar;
    private TextView mTextViewSigUpLink;
    private static final String PREFS_NAME = HolterMonitorConstants.PREFS_NAME;
    private SharedPreferences sharedPreferences;
    private boolean isUserRegistered;
    private boolean isLoggedIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
    }

    private void initViews() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, 0);
        isUserRegistered = sharedPreferences.getBoolean("is_registered", false);
        isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false);
        if (isLoggedIn) {
            startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
        }
        mToolbar = findViewById(R.id.login_bar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Login");
        }

        mTextViewSigUpLink = findViewById(R.id.text_sign_up_link);
        mTextViewSigUpLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SignupActivity.class));
            }
        });

        mTextInputEmail = findViewById(R.id.text_input_email);
        mEditTextEmail = findViewById(R.id.text_edit_email);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String userEmail = sharedPreferences.getString("email", null);

        if (userEmail != null) {
            mEditTextEmail.setText(userEmail);
        }

        mTextInputPassword = findViewById(R.id.text_input_password);
        mEditTextPassword = findViewById(R.id.text_edit_password);
        Button mBtnLogin = findViewById(R.id.btn_login);

        mEditTextEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (validateEmail(Objects.requireNonNull(mEditTextEmail.getText()).toString())) {
                    mTextInputEmail.setError(null);
                    mTextInputEmail.setHint("");
                    mTextInputEmail.setHintEnabled(false);
                    mTextInputEmail.requestLayout();
                }
            }
        });

        mEditTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (validatePassword(Objects.requireNonNull(mEditTextPassword.getText()).toString())) {
                    mTextInputPassword.setError(null);
                    mTextInputPassword.setHint("");
                    mTextInputPassword.setHintEnabled(false);
                    mTextInputPassword.requestLayout();
                }
            }
        });

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Objects.requireNonNull(mEditTextEmail.getText()).toString().trim();
                String password = Objects.requireNonNull(mEditTextPassword.getText()).toString().trim();
                loginUser(email, password);
            }
        });

    }

    private void loginUser(String email, String password) {

        if (validateEmail(email) && validatePassword(password)) {
            if (isUserRegistered) {
                setIsLoggedIn();
                startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
            } else {
                Toast.makeText(LoginActivity.this, "Sign up required", Toast.LENGTH_LONG).show();
            }

        }

    }

    private boolean validateEmail(String email) {

        if (email.isEmpty()) {
            mTextInputEmail.setError("Email is required");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mTextInputEmail.setError("Please enter a valid email address");
            mTextInputEmail.setHintEnabled(true);
            return false;
        } else {
            mTextInputEmail.setError(null);
            mTextInputEmail.setHint("");
            mTextInputEmail.setHintEnabled(false);
            mTextInputEmail.requestLayout();
            return true;
        }
    }

    private boolean validatePassword(String password) {

        if (password.isEmpty()) {
            mTextInputPassword.setError("Password is required");
            mTextInputPassword.setHintEnabled(true);
            return false;
        } else if (password.length() < 6) {
            mTextInputPassword.setError("Password must be at least 6 characters long");
            mTextInputPassword.setHintEnabled(true);
            return false;
        } else if (password.length() > 10) {
            mTextInputPassword.setError("Password length must be less than or equal to 10 characters");
            mTextInputPassword.setHintEnabled(true);
            return false;
        } else {
            mTextInputPassword.setError(null);
            mTextInputPassword.setHint("");
            mTextInputPassword.setHintEnabled(false);
            mTextInputPassword.requestLayout();
            return true;
        }
    }

    private void setIsLoggedIn () {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("is_logged_in", true);
        editor.apply();
    }

}