package com.holter.holtermonitor.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.holter.holtermonitor.R;
import com.holter.holtermonitor.db.entity.HeartRate;

import java.util.List;

public class HeartRateAdapter extends RecyclerView.Adapter<HeartRateAdapter.ViewHolder> {

    private List<HeartRate> dataSet;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        public ViewHolder(View view) {
            super(view);
            textView = view.findViewById(R.id.textView);
        }
    }

    public HeartRateAdapter(List<HeartRate> dataSet) {
        this.dataSet = dataSet;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.history_item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.textView.setText(String.valueOf(dataSet.get(position).value));
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public void addData(List<HeartRate> newItems) {
        int startPosition = dataSet.size();
        dataSet.addAll(newItems);
        notifyItemRangeInserted(startPosition, newItems.size());
    }

    public void clearData() {
        int size = dataSet.size();
        if (size > 0) {
            dataSet.clear();
            notifyItemRangeRemoved(0, size);
        }
    }
}
