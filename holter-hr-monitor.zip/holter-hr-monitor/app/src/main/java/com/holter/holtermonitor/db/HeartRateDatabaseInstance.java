package com.holter.holtermonitor.db;

import android.content.Context;

import androidx.room.Room;


public class HeartRateDatabaseInstance {
    private static HeartRateDatabase database;

    public static HeartRateDatabase getInstance(Context context) {
        if (database == null) {
            database = Room.databaseBuilder(context, HeartRateDatabase.class, "holter_monitor_db")
                    .allowMainThreadQueries()
                    .build();
        }
        return database;
    }
}
