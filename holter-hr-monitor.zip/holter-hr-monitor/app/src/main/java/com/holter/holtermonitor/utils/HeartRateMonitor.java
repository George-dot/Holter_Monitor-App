package com.holter.holtermonitor.utils;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.os.Looper;
import android.os.Handler;


import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.preference.PreferenceManager;

import com.google.android.material.snackbar.Snackbar;
import com.holter.holtermonitor.R;
import com.holter.holtermonitor.ui.DashboardActivity;


public class HeartRateMonitor {
    private Context context;
    private static final String CHANNEL_ID = "heart_rate_channel";
    private static final int NOTIFICATION_ID = 001;
    public static final int REQUEST_CODE_NOTIFICATION_PERMISSION = 1001;
    private int lastHeartRate = -1;
    private long lastHeartRateTimestamp = 0;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable checkHeartRateRunnable;

    public HeartRateMonitor(Context context) {
        this.context = context;
        createNotificationChannel();
    }

    private void silenceDevice(View view) {
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            audioManager.setStreamVolume(AudioManager.STREAM_RING, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            Log.d("HeartRateMonitor", "Device silenced due to high heart rate");
            displaySnackBar(view);
        }
    }


    public void onHeartRateChanged(int heartRate, int maxHeartRate) {
        boolean silenceAlarm = PreferenceManager.getDefaultSharedPreferences(context)
                .getBoolean("silence_alarm", false);

        if (heartRate > maxHeartRate) {
            if (heartRate == lastHeartRate) {
                // if the heart rate is the same, check if 30 seconds have passed
                if (System.currentTimeMillis() - lastHeartRateTimestamp >= 30000) {
                    if (silenceAlarm) {
                        Activity activity = (Activity) context;
                        View view = activity.findViewById(android.R.id.content);
                        silenceDevice(view);
                    } else {
                        vibrateAndNotify();
                    }
                }
            } else {

                lastHeartRate = heartRate;
                lastHeartRateTimestamp = System.currentTimeMillis();


                if (checkHeartRateRunnable != null) {
                    handler.removeCallbacks(checkHeartRateRunnable);
                }

                checkHeartRateRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (heartRate == lastHeartRate && System.currentTimeMillis() - lastHeartRateTimestamp >= 30000) {
                            if (silenceAlarm) {
                                Activity activity = (Activity) context;
                                View view = activity.findViewById(android.R.id.content);
                                silenceDevice(view);
                            } else {
                                vibrateAndNotify();
                            }
                        }
                    }
                };

                handler.postDelayed(checkHeartRateRunnable, 30000);
            }
        } else {

            lastHeartRate = -1;
            if (checkHeartRateRunnable != null) {
                handler.removeCallbacks(checkHeartRateRunnable);
            }
        }
    }

    public void vibrateAndNotify() {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(500);
            }
        }



        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ActivityCompat.requestPermissions((Activity) context,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_CODE_NOTIFICATION_PERMISSION);
            }


            if (context instanceof DashboardActivity) {
                ((DashboardActivity) context).setPendingNotification(true);
            }
            return;
        }

        Intent intent = new Intent(context, DashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon_ecg_heart)
                .setContentTitle("High Heart Rate Alert")
                .setContentText("Your heart rate is high")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Heart Rate";
            String description = "High heart rate recorded";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    private void displaySnackBar(View view) {
        Snackbar snackbar = Snackbar.make(view, "Device silenced due to high heart rate", Snackbar.LENGTH_INDEFINITE)
                .setActionTextColor(context.getResources().getColor(R.color.md_theme_secondary));

        snackbar.show();
    }
}


