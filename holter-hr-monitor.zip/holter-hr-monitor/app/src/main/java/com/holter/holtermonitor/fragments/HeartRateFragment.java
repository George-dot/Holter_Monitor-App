package com.holter.holtermonitor.fragments;

import static com.holter.holtermonitor.utils.HolterMonitorConstants.PAGE_SIZE;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;

import com.holter.holtermonitor.R;
import com.holter.holtermonitor.db.entity.HeartRate;
import com.holter.holtermonitor.db.HeartRateDao;
import com.holter.holtermonitor.db.HeartRateDatabase;
import com.holter.holtermonitor.db.HeartRateDatabaseInstance;
import com.holter.holtermonitor.utils.AppUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HeartRateFragment extends Fragment {
    private static final String TAG = HeartRateFragment.class.getSimpleName();
    private List<HeartRate> dataSet;
    private HeartRateDao heartRateDao;
    private TableLayout tableLayout;
    private HeartRateDatabase db;
    private boolean isLoading = false;
    private int currentOffset = 0;
    private int rows = 0;
    private int columns = 2;

    public HeartRateFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_heart_rate, container, false);
        tableLayout = view.findViewById(R.id.tableLayoutHeartRate);

        db = HeartRateDatabaseInstance.getInstance(requireActivity().getApplicationContext());
        heartRateDao = db.heartRateDao();

        dataSet = heartRateDao.getHeartRates(PAGE_SIZE, currentOffset);
        currentOffset += dataSet.size();

        if (dataSet.size() > 0) {
            addHeaderToTable();
            addRowsToTable();

            requireActivity().addMenuProvider(new MenuProvider() {
                @Override
                public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                    menuInflater.inflate(R.menu.history_menu, menu);
                }

                @Override
                public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                    if (menuItem.getItemId() == R.id.action_history_clear) {
                        clearHistory();
                        return true;
                    }
                    return false;
                }
            }, getViewLifecycleOwner(), Lifecycle.State.RESUMED);
        }


        view.findViewById(R.id.scrollview_heart_rate).setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (scrollY == (v.getMeasuredHeight() - v.getHeight())) {
                    if (!isLoading) {
                        loadMoreData();
                    }
                }
            }
        });

        return view;
    }

    private void addHeaderToTable() {
        TableRow tableRow = new TableRow(requireActivity());
        tableRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
        tableRow.setBackgroundColor(getResources().getColor(R.color.md_theme_primary));

        TextView headerHeartRate = new TextView(requireActivity());
        headerHeartRate.setText(getResources().getString(R.string.readings_text_heart_rate));
        headerHeartRate.setTextColor(ContextCompat.getColor(requireActivity(), R.color.white));
        headerHeartRate.setPadding(10, 35, 10, 35);
        headerHeartRate.setGravity(Gravity.CENTER);
        headerHeartRate.setTextSize(18);
        tableRow.addView(headerHeartRate);

        TextView headerTimeStamp = new TextView(requireActivity());
        headerTimeStamp.setText(getResources().getString(R.string.time_stamp));
        headerTimeStamp.setTextColor(ContextCompat.getColor(requireActivity(), R.color.white));
        headerTimeStamp.setPadding(10, 35, 10, 35);
        headerTimeStamp.setGravity(Gravity.CENTER);
        headerTimeStamp.setTextSize(18);
        tableRow.addView(headerTimeStamp);

        tableLayout.addView(tableRow, 0);
    }

    private void addRowsToTable() {
        for (int i = 0; i < dataSet.size(); i++) {
            TableRow tableRow = new TableRow(requireActivity());
            tableRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            tableRow.setBackgroundResource(R.drawable.table_row_border);

            TextView textViewHeartRate = new TextView(requireActivity());
            textViewHeartRate.setText(String.valueOf(dataSet.get(i).value));
            textViewHeartRate.setPadding(10, 25, 10, 25);
            textViewHeartRate.setGravity(Gravity.CENTER);
            textViewHeartRate.setTextSize(14);
            tableRow.addView(textViewHeartRate);


            TextView textViewTimeStamp = new TextView(requireActivity());
            textViewTimeStamp.setText(AppUtils.formatTimestamp(dataSet.get(i).timestamp));
            textViewTimeStamp.setPadding(10, 25, 10, 25);
            textViewTimeStamp.setGravity(Gravity.CENTER);
            textViewTimeStamp.setTextSize(14);
            tableRow.addView(textViewTimeStamp);

            tableLayout.addView(tableRow, i + 1);
        }
    }

    private void loadMoreData() {
        isLoading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<HeartRate> newItems = heartRateDao.getHeartRates(PAGE_SIZE, currentOffset);
                if (!newItems.isEmpty()) {
                    currentOffset += newItems.size();
                    dataSet.addAll(newItems);
                    requireActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tableLayout.removeAllViews();
                            addHeaderToTable();
                            addRowsToTable();
                        }
                    });
                }
                isLoading = false;
            }
        }).start();
    }

    private void clearHistory() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                heartRateDao.clearAll();
                requireActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tableLayout.removeAllViews();
                        addHeaderToTable();
                        currentOffset = 0;
                        Toast.makeText(getActivity(), "History cleared", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();
    }
}
