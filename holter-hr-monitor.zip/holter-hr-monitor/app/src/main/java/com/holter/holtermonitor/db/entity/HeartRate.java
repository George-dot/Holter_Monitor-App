package com.holter.holtermonitor.db.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class HeartRate {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public float value;
    public long timestamp;

    public HeartRate(float value, long timestamp) {
        this.value = value;
        this.timestamp = timestamp;
    }
}
