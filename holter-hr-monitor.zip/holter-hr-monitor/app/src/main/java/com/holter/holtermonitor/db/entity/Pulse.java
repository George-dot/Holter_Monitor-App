package com.holter.holtermonitor.db.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Pulse {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public float value;
    public long timestamp;

    public Pulse(float value, long timestamp) {
        this.value = value;
        this.timestamp = timestamp;
    }
}
