package com.holter.holtermonitor.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.text.Html;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.holter.holtermonitor.R;
import com.holter.holtermonitor.ui.AboutActivity;

import java.util.Objects;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);

        Preference aboutPreference = findPreference("about");
        if (aboutPreference != null) {
            aboutPreference.setOnPreferenceClickListener(preference -> {
                startActivity(new Intent(getActivity(), AboutActivity.class));
                return true;
            });
        }

        Preference helpPreference = findPreference("help");
        if (helpPreference != null) {
            helpPreference.setOnPreferenceClickListener(preference -> {
                showHelpDialog();
                return true;
            });
        }


    }


    private void showHelpDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(R.string.help_dialog_title);
        builder.setMessage(Html.fromHtml(getString(R.string.help_dialog_message)));
        builder.setPositiveButton(R.string.help_ok, (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }
}
