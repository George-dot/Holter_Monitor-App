package com.holter.holtermonitor.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.holter.holtermonitor.db.entity.HeartRate;
import com.holter.holtermonitor.db.entity.Pulse;

import java.util.List;

@Dao
public interface HeartRateDao {
    @Insert
    void insert(HeartRate heartRate);

    @Query("SELECT * FROM HeartRate LIMIT :limit OFFSET :offset")
    List<HeartRate> getHeartRates(int limit, int offset);

    @Query("DELETE FROM HeartRate")
    void clearAll();


    @Insert
    void insertPulse(Pulse pulse);

    @Query("SELECT * FROM Pulse LIMIT :limit OFFSET :offset")
    List<Pulse> getPulses(int limit, int offset);

    @Query("DELETE FROM Pulse")
    void clearAllPulses();


}
