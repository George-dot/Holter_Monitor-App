package com.holter.holtermonitor.utils;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AppUtils {

    /**
     * Calculates the heart rate in beats per minute using the payload value received from the MQTT device
     * RR interval is a measure of the interval between two heart beats
     * For example, Payload 1571.00 indicates that the interval between two heartbeats is 1571 milliseconds.
     *
     * @return the hearts rate in beats per minute
     */
    public static double calculateHeartRate(double rrInterval) {
        if (rrInterval <= 0) {
            return 0;
        }
        return HolterMonitorConstants.SIXTY_SECONDS / rrInterval;
    }

    /**
     * Returns user intensity level state based on the activity status
     **/
    public static double RestingLevel(String intensity) {
        switch (intensity) {
            case HolterMonitorConstants.RESTING:
                return HolterMonitorConstants.RESTING_LEVEL;
            case HolterMonitorConstants.NORMAL_AEROBICS:
                return HolterMonitorConstants.NORMAL_AEROBICS_LEVEL;
            case HolterMonitorConstants.HARD_AEROBICS:
                return HolterMonitorConstants.HARD_AEROBICS_LEVEL;
            default:
                return HolterMonitorConstants.DEFAULT_LEVEL;
        }
    }

    public static double maximumHeartRate(int age, double intensityLevel) {
        return 211 - (intensityLevel * age);
    }

    public static int calculateAge(String birthDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {

            Date birthDateParsed = sdf.parse(birthDate);
            if (birthDateParsed == null) {
                return 0;
            }


            Calendar birthDateCalendar = Calendar.getInstance();
            birthDateCalendar.setTime(birthDateParsed);

            Calendar currentDate = Calendar.getInstance();


            int age = currentDate.get(Calendar.YEAR) - birthDateCalendar.get(Calendar.YEAR);


            if (currentDate.get(Calendar.MONTH) < birthDateCalendar.get(Calendar.MONTH) ||
                    (currentDate.get(Calendar.MONTH) == birthDateCalendar.get(Calendar.MONTH) &&
                            currentDate.get(Calendar.DAY_OF_MONTH) < birthDateCalendar.get(Calendar.DAY_OF_MONTH))) {
                age--;
            }

            return age;
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static double formatDecimal (double value) {
        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.HALF_UP);

        return Double.parseDouble(df.format(value));
    }

    public static String formatTimestamp(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date(timestamp);
        return sdf.format(date);
    }

}
