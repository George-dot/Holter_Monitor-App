package com.holter.holtermonitor.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.holter.holtermonitor.fragments.ECGFragment;
import com.holter.holtermonitor.fragments.HeartRateFragment;

public class HistoryPagerAdapter extends FragmentStateAdapter {

    private static final int ITEM_COUNT = 2;

    public HistoryPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new ECGFragment();
            case 1:
                return new HeartRateFragment();
            default:
                throw new IllegalArgumentException("Invalid position: " + position);
        }
    }

    @Override
    public int getItemCount() {
        return ITEM_COUNT;
    }
}
