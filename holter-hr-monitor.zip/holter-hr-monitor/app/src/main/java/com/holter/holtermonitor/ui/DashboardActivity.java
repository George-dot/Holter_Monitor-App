package com.holter.holtermonitor.ui;

import static com.holter.holtermonitor.utils.HolterMonitorConstants.PREFS_NAME;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.Toolbar;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.chip.Chip;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textview.MaterialTextView;
import com.holter.holtermonitor.R;

import com.holter.holtermonitor.db.entity.HeartRate;
import com.holter.holtermonitor.db.HeartRateDao;
import com.holter.holtermonitor.db.HeartRateDatabase;
import com.holter.holtermonitor.db.HeartRateDatabaseInstance;
import com.holter.holtermonitor.db.entity.Pulse;
import com.holter.holtermonitor.utils.AppUtils;
import com.holter.holtermonitor.utils.HeartRateMonitor;
import com.holter.holtermonitor.utils.HolterMonitorConstants;
import com.holter.holtermonitor.utils.NetworkHelper;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import android.os.Handler;

import info.mqtt.android.service.MqttAndroidClient;

public class DashboardActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = DashboardActivity.class.getSimpleName();
    private Toolbar mToolbar;
    private LineChart lineChart, pulseChart;
    private MqttAndroidClient mqttClient;
    private LineDataSet dataSet, pulseDataSet;
    private LineData lineData, pulseData;
    private List<Entry> entries = new ArrayList<>();
    private List<Entry> pulseEntries = new ArrayList<>();
    private Handler mainHandler;
    private Handler textHandler;
    private List<Float> heartRateBuffer = new CopyOnWriteArrayList<>();
    private Chip chipStatus;
    private AppCompatSpinner spinner;
    private MaterialTextView mTextView;
    private MaterialTextView mMeasurement;
    private HeartRateMonitor heartRateMonitor;
    private boolean pendingNotification = false;
    private HeartRateDao heartRateDao;
    private HeartRateDatabase heartRateDatabase;
    private String activityLevel = "";
    private String birthday = "";
    private SharedPreferences sharedPreferences;
    private List<Double> payloadBuffer = new ArrayList<>();
    private List<Float> pulseBuffer = new ArrayList<>();

    @Override
    int getContentViewId() {
        return R.layout.activity_dashboard;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.item_dashboard;
    }

    @SuppressLint("SetTextI18n")
    @Override
    void init() {
        mToolbar = findViewById(R.id.main_bar);

        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Status");
        }
        heartRateMonitor = new HeartRateMonitor(this);
        heartRateDatabase = HeartRateDatabaseInstance.getInstance(getApplicationContext());
        heartRateDao = heartRateDatabase.heartRateDao();

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        birthday = sharedPreferences.getString("birthday", null);


        boolean isConnected = NetworkHelper.isNetworkConnected(getApplicationContext());
        setActionBarStatus(isConnected ? "Online" : "Offline");
        mainHandler = new Handler(Looper.getMainLooper());
        textHandler = new Handler();

        if (!isConnected) {
            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Network isn't available", Snackbar.LENGTH_INDEFINITE)
                    .setAction("Connect", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openInternetSettings();
                        }
                    })
                    .setActionTextColor(getResources().getColor(R.color.md_theme_secondary));

            snackbar.show();

        }

        mTextView = findViewById(R.id.text_view_current_heart_rate);
        mMeasurement = findViewById(R.id.text_view_measurement);



        lineChart = findViewById(R.id.line_chart);
        pulseChart = findViewById(R.id.pulse_chart);


        initialiseSpinner();
        setupCharts();
        connectMqttService();
        startChartUpdater();
        startTextAnimation();

    }

    private void initialiseSpinner() {
        spinner = findViewById(R.id.activity_status);
        chipStatus = findViewById(R.id.chip_status);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.status_array, R.layout.item_spinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        String[] keys = getResources().getStringArray(R.array.status_array_keys);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                chipStatus.setText(selectedItem);
                activityLevel = keys[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    private void setupCharts() {
        dataSet = new LineDataSet(entries, "Heart Rate");
        pulseDataSet = new LineDataSet(pulseEntries, "Pulse");

        setupChart(lineChart, dataSet, Color.RED, LineDataSet.Mode.CUBIC_BEZIER, HolterMonitorConstants.HEART_RHYTHM_SUBSCRIPTION);
        setupChart(pulseChart, pulseDataSet, Color.BLUE, LineDataSet.Mode.LINEAR, HolterMonitorConstants.PULSE_SUBSCRIPTION);


    }

    private void setupChart(LineChart chart, LineDataSet dataSet, int color, LineDataSet.Mode mode, String topic) {

        dataSet.setColor(color);
        dataSet.setMode(mode);
        dataSet.setDrawCircles(false);


        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);


        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
        chart.setDoubleTapToZoomEnabled(true);
        chart.getAxisRight().setEnabled(false);
        chart.getDescription().setEnabled(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawLabels(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);

        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setDrawLabels(false);
        leftAxis.setDrawAxisLine(false);
        leftAxis.setDrawGridLines(false);


        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);


        if (topic.equals(HolterMonitorConstants.PULSE_SUBSCRIPTION)) {

            dataSet.setDrawValues(false);
            dataSet.setDrawCircles(false);
            dataSet.setValueTextSize(10f);
            chart.setMaxVisibleValueCount(5);

            xAxis.setDrawLabels(false);
            xAxis.setDrawAxisLine(false);
            xAxis.setDrawGridLines(false);
            xAxis.setGridColor(Color.GRAY);
            xAxis.setGridLineWidth(0.5f);


            leftAxis.setDrawLabels(true);
            leftAxis.setDrawAxisLine(true);
            leftAxis.setDrawGridLines(true);
            leftAxis.setGridColor(Color.GRAY);
            leftAxis.setGridLineWidth(0.5f);


        } else {
            dataSet.setDrawCircles(false);
            dataSet.setDrawValues(false);
        }

        chart.invalidate();
    }

    @Override
    public void onClick(View v) {

    }


    private void connectMqttService() {
        String clientId = MqttClient.generateClientId();
        mqttClient = new MqttAndroidClient(this.getApplicationContext(), HolterMonitorConstants.SERVER_URI, clientId);


        try {
            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    // Handle connection loss
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) {
                    final String payload = new String(message.getPayload());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (topic.equals(HolterMonitorConstants.HEART_RHYTHM_SUBSCRIPTION)) {
                                    double payloadValue = Double.parseDouble(payload);
                                    payloadBuffer.add(payloadValue);
                                    heartRateBuffer.add((float) payloadValue);
                                } else if (topic.equals(HolterMonitorConstants.PULSE_SUBSCRIPTION)) {
                                    double payloadValue = Double.parseDouble(payload);
                                    if (payloadValue >= 40) {
                                        pulseBuffer.add((float) AppUtils.formatDecimal(payloadValue));
                                    }
                                }


                                Log.d(TAG, "Payload" + payload);
                            } catch (NumberFormatException e) {
                                Log.e(TAG, "Invalid payload", e);
                            }
                        }
                    });
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(String.valueOf(DashboardActivity.this), "Delivery complete: ");
                        }
                    });
                }
            });


            MqttConnectOptions options = new MqttConnectOptions();
            options.setAutomaticReconnect(true);
            options.setCleanSession(false);

            mqttClient.connect(options, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            setActionBarStatus("Online");


                            try {
                                String[] topics = {HolterMonitorConstants.HEART_RHYTHM_SUBSCRIPTION, HolterMonitorConstants.PULSE_SUBSCRIPTION};
                                int[] qos = {1, 1};

                                mqttClient.subscribe(topics, qos, null, new IMqttActionListener() {
                                    @Override
                                    public void onSuccess(IMqttToken asyncActionToken) {
                                        runOnUiThread(new Runnable() {
                                            public void run() {
                                                Log.d(TAG, "Subscription is successful");
                                            }
                                        });
                                    }

                                    @Override
                                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                                        runOnUiThread(new Runnable() {
                                            public void run() {
                                                Toast.makeText(DashboardActivity.this,
                                                        "Error connecting to server: " + asyncActionToken.getMessageId(),
                                                        Toast.LENGTH_LONG).show();
                                            }
                                        });
                                    }
                                });
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            setActionBarStatus("Disconnected");
                        }
                    });
                    exception.printStackTrace();
                }
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    private void startChartUpdater() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateCharts();
                mainHandler.postDelayed(this, 10000);
            }
        }, 10000);
    }

    private void startTextAnimation() {
        textHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ObjectAnimator fadeOut = ObjectAnimator.ofFloat(mTextView, "alpha", 1f, 0f);
                fadeOut.setDuration(5000);
                fadeOut.setInterpolator(new AccelerateInterpolator());

                ObjectAnimator fadeIn = ObjectAnimator.ofFloat(mTextView, "alpha", 0f, 1f);
                fadeIn.setDuration(5000);
                fadeIn.setInterpolator(new AccelerateInterpolator());

                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.playSequentially(fadeOut, fadeIn);

                animatorSet.start();

                textHandler.postDelayed(this, 5000);
            }
        }, 5000);
    }

    private void processECGSignalAndUpdateChart() {
        if (!heartRateBuffer.isEmpty()) {
            entries.clear();


            for (int i = 0; i < heartRateBuffer.size(); i++) {
                entries.add(new Entry(entries.size(), heartRateBuffer.get(i) * 7.0f));
            }

            Log.d(TAG, "Entries size"  + String.valueOf(entries.size()));
            heartRateBuffer.clear();
            dataSet.notifyDataSetChanged();
            lineData.notifyDataChanged();
            lineChart.notifyDataSetChanged();
            lineChart.invalidate();

            lineChart.moveViewToX(entries.size());
            lineChart.animateX(1000);
        }
    }

    private void updateCharts() {
        if (!pulseBuffer.isEmpty()) {
            float currentHeartRate = getRandomValueFromBuffer(pulseBuffer);
            setHeartRate(currentHeartRate);
        }

        if (!heartRateBuffer.isEmpty()) {
            for (Float ecgValue : heartRateBuffer) {
                heartRateDao.insertPulse(new Pulse(ecgValue, System.currentTimeMillis()));
            }
        }

        updateChart(lineChart, dataSet, heartRateBuffer, entries, HolterMonitorConstants.HEART_RHYTHM_SUBSCRIPTION);
        updateChart(pulseChart, pulseDataSet, pulseBuffer, pulseEntries, HolterMonitorConstants.PULSE_SUBSCRIPTION);

    }

    private void updateChart(LineChart chart, LineDataSet dataSet, List<Float> buffer, List<Entry> entries, String topic) {
        if (!buffer.isEmpty()) {
            entries.clear();


            if (topic.equals(HolterMonitorConstants.PULSE_SUBSCRIPTION)) {

                for (int i = 0; i < buffer.size(); i++) {
                    float value = buffer.get(i);
                    entries.add(new Entry(i, value));
                }

                YAxis leftAxis = chart.getAxisLeft();
                leftAxis.setAxisMinimum(0f);
                leftAxis.setAxisMaximum(250f);
                leftAxis.setLabelCount(5, true);
            } else {

                for (int i = 0; i < buffer.size(); i++) {
                    entries.add(new Entry(i, buffer.get(i) * 7.0f));
                }
            }

            buffer.clear();

            dataSet.notifyDataSetChanged();
            LineData data = new LineData(dataSet);
            chart.setData(data);
            data.notifyDataChanged();
            chart.notifyDataSetChanged();
            chart.invalidate();

            chart.moveViewToX(entries.size());
            chart.animateX(1000);
        }
    }


    private float getRandomValueFromBuffer(List<Float> buffer) {
        Random random = new Random();
        int randomIndex = random.nextInt(buffer.size());
        return buffer.get(randomIndex);
    }

    private void setHeartRate(float maxHeartRate) {
        mTextView.setText(String.valueOf(maxHeartRate));
        onHeartRateChanged((int) maxHeartRate);
    }


    private void setActionBarStatus(String status) {
        Objects.requireNonNull(getSupportActionBar()).setSubtitle(status);
    }

    private void openInternetSettings() {
        Intent settingsIntent = new Intent(android.provider.Settings.ACTION_SETTINGS);
        startActivityForResult(settingsIntent, HolterMonitorConstants.REQUEST_ENABLE_WIFI);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == HolterMonitorConstants.REQUEST_ENABLE_WIFI) {
            if (NetworkHelper.isNetworkConnected(getApplicationContext())) {
                setActionBarStatus("Online");
                Toast.makeText(getApplicationContext(), "Connected successfully", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Internet connection could not be enabled", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == HeartRateMonitor.REQUEST_CODE_NOTIFICATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingNotification) {
                    heartRateMonitor.vibrateAndNotify();
                    pendingNotification = false;
                }
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void onHeartRateChanged(int heartRate) {
        int age = AppUtils.calculateAge(birthday);
        double restingLevel = AppUtils.RestingLevel(activityLevel);
        double maximumHeartRate = AppUtils.maximumHeartRate(age, restingLevel);

        insertDataToDatabase(heartRate);
        heartRateMonitor.onHeartRateChanged(heartRate, (int) maximumHeartRate);
    }

    public void setPendingNotification(boolean pendingNotification) {
        this.pendingNotification = pendingNotification;
    }

    private void insertDataToDatabase(float value) {
        heartRateDao.insert(new HeartRate(value, System.currentTimeMillis()));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mainHandler.removeCallbacksAndMessages(null);
        textHandler.removeCallbacksAndMessages(null);

        if (mqttClient != null && mqttClient.isConnected()) {
            try {
                mqttClient.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}