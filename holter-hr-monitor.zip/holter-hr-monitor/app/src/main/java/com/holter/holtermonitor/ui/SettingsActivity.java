package com.holter.holtermonitor.ui;

import androidx.appcompat.widget.Toolbar;

import com.holter.holtermonitor.R;
import com.holter.holtermonitor.fragments.SettingsFragment;

import java.util.Objects;

public class SettingsActivity extends BaseActivity {

    @Override
    int getContentViewId() {
        return R.layout.activity_settings;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.item_settings;
    }

    @Override
    void init() {
        Toolbar mToolbar = findViewById(R.id.settings_app_bar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Settings");
        }

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings_container, new SettingsFragment())
                .commit();
    }
}
