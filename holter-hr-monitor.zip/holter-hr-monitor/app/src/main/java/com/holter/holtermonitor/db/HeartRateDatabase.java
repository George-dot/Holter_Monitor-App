package com.holter.holtermonitor.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.holter.holtermonitor.db.entity.HeartRate;
import com.holter.holtermonitor.db.entity.Pulse;

@Database(entities = {HeartRate.class, Pulse.class}, version = 1)
public abstract class HeartRateDatabase extends RoomDatabase {
    public abstract HeartRateDao heartRateDao();
}

