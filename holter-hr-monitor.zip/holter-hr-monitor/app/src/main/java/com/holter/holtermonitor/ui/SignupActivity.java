package com.holter.holtermonitor.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;


import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.holter.holtermonitor.R;
import com.holter.holtermonitor.utils.HolterMonitorConstants;
import com.google.android.material.datepicker.DateValidatorPointBackward;


import java.util.Calendar;
import java.util.Objects;

public class SignupActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private static final String PREFS_NAME = HolterMonitorConstants.PREFS_NAME;
    private SharedPreferences sharedPreferences;
    private TextInputEditText mEditTextEmail;
    private TextInputLayout mTextInputEmail;
    private TextInputEditText mEditTextPassword;
    private TextInputLayout mTextInputPassword;

    private TextInputEditText mEditTextConfirmPassword;
    private TextInputLayout mTextInputConfirmPassword;
    private TextInputLayout mTextInputBirthDay;
    private TextInputEditText mEditTextBirthday;
    private Button mBtnSignup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        setContentView(R.layout.activity_signup);
        initViews();
    }


    private void initViews() {
        mToolbar = findViewById(R.id.signup_bar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Sign up");
        }

        mTextInputEmail = findViewById(R.id.text_input_email);
        mEditTextEmail = findViewById(R.id.text_edit_email);

        mTextInputPassword = findViewById(R.id.text_input_password);
        mEditTextPassword = findViewById(R.id.text_edit_password);

        mTextInputPassword = findViewById(R.id.text_input_password);
        mEditTextPassword = findViewById(R.id.text_edit_password);

        mTextInputConfirmPassword = findViewById(R.id.text_input_confirm_password);
        mEditTextConfirmPassword = findViewById(R.id.text_edit_confirm_password);

        mTextInputBirthDay = findViewById(R.id.text_input_birth_day);
        mEditTextBirthday = findViewById(R.id.text_edit_birth_day);

        mBtnSignup = findViewById(R.id.btn_create_account);

        mEditTextEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (validateEmail(Objects.requireNonNull(mEditTextEmail.getText()).toString())) {
                    mTextInputEmail.setError(null);
                    mTextInputEmail.setHint("");
                    mTextInputEmail.setHintEnabled(false);
                    mTextInputEmail.requestLayout();
                }
            }
        });


        mEditTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (validatePassword(Objects.requireNonNull(mEditTextPassword.getText()).toString())) {
                    mTextInputPassword.setError(null);
                    mTextInputPassword.setHint("");
                    mTextInputPassword.setHintEnabled(false);
                    mTextInputPassword.requestLayout();
                }
            }
        });

        mEditTextConfirmPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (validateConfirmPassword(Objects.requireNonNull(mEditTextConfirmPassword.getText()).toString(),
                        Objects.requireNonNull(mEditTextPassword.getText()).toString())) {
                    mTextInputConfirmPassword.setError(null);
                    mTextInputConfirmPassword.setHint("");
                    mTextInputConfirmPassword.setHintEnabled(false);
                    mTextInputConfirmPassword.requestLayout();
                }
            }
        });

        initialiseDatePicker();



        mBtnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = Objects.requireNonNull(mEditTextEmail.getText()).toString().trim();
                String password = Objects.requireNonNull(mEditTextPassword.getText()).toString().trim();
                String confirmPassword = Objects.requireNonNull(mEditTextConfirmPassword.getText()).toString().trim();
                String birthday = Objects.requireNonNull(mEditTextBirthday.getText()).toString().trim();
                signUpUser(email, password, confirmPassword, birthday);
            }
        });
    }

    private void signUpUser(String email, String password, String confirmPassword, String birthday) {

        if (validateEmail(email) && validatePassword(password) && validateConfirmPassword(confirmPassword, password)) {
            setIsLoggedIn(email, birthday);
            startActivity(new Intent(SignupActivity.this, LoginActivity.class));
        }

    }

    private boolean validateEmail(String email) {

        if (email.isEmpty()) {
            mTextInputEmail.setError("Email is required");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mTextInputEmail.setError("Please enter a valid email address");
            mTextInputEmail.setHintEnabled(true);
            return false;
        } else {
            mTextInputEmail.setError(null);
            mTextInputEmail.setHint("");
            mTextInputEmail.setHintEnabled(false);
            mTextInputEmail.requestLayout();
            return true;
        }
    }

    private boolean validatePassword(String password) {
        if (password.isEmpty()) {
            mTextInputPassword.setError("Password is required");
            mTextInputPassword.setHintEnabled(true);
            return false;
        } else if (password.length() < 6) {
            mTextInputPassword.setError("Password must be at least 6 characters long");
            mTextInputPassword.setHintEnabled(true); // Enable hint
            return false;
        } else if (password.length() > 10) {
            mTextInputPassword.setError("Password length must be less than or equal to 10 characters");
            mTextInputPassword.setHintEnabled(true);
            return false;
        } else {
            mTextInputPassword.setError(null);
            mTextInputPassword.setHint("");
            mTextInputPassword.setHintEnabled(false);
            mTextInputPassword.requestLayout();
            return true;
        }
    }

    private boolean validateConfirmPassword(String confirmPassword, String password) {
        if (confirmPassword.isEmpty()) {
            mTextInputConfirmPassword.setError("Confirm Password is required");
            mTextInputConfirmPassword.setHintEnabled(true);
            return false;
        } else if (confirmPassword.length() < 6) {
            mTextInputConfirmPassword.setError("Password must be at least 6 characters long");
            mTextInputConfirmPassword.setHintEnabled(true);
            return false;
        } else if (!confirmPassword.equals(password)) {
            mTextInputConfirmPassword.setError("Passwords do not match");
            mTextInputConfirmPassword.setHintEnabled(true);
            return false;
        } else if (confirmPassword.length() > 10) {
            mTextInputConfirmPassword.setError("Password length must be less than or equal to 10 characters");
            mTextInputConfirmPassword.setHintEnabled(true);
            return false;
        } else {
            mTextInputConfirmPassword.setError(null);
            mTextInputConfirmPassword.setHint("");
            mTextInputConfirmPassword.setHintEnabled(false);
            mTextInputConfirmPassword.requestLayout();
            return true;
        }
    }

    private  void initialiseDatePicker () {
        CalendarConstraints.Builder constraintsBuilder = new CalendarConstraints.Builder();
        constraintsBuilder.setValidator(DateValidatorPointBackward.now());

        MaterialDatePicker.Builder<Long> datePickerBuilder = MaterialDatePicker.Builder.datePicker();
        datePickerBuilder.setTitleText("Select Birth Date");
        datePickerBuilder.setCalendarConstraints(constraintsBuilder.build());
        final MaterialDatePicker<Long> datePicker = datePickerBuilder.build();

        View.OnClickListener datePickerOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker.show(getSupportFragmentManager(), "MATERIAL_DATE_PICKER");
            }
        };

        mEditTextBirthday.setOnClickListener(datePickerOnClickListener);
        mTextInputBirthDay.setEndIconOnClickListener(datePickerOnClickListener);

        datePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener<Long>() {
            @Override
            public void onPositiveButtonClick(Long selection) {
                Calendar selectedDate = Calendar.getInstance();
                selectedDate.setTimeInMillis(selection);
                int year = selectedDate.get(Calendar.YEAR);
                int month = selectedDate.get(Calendar.MONTH) + 1;
                int day = selectedDate.get(Calendar.DAY_OF_MONTH);

                Calendar currentDate = Calendar.getInstance();

                if (selectedDate.after(currentDate)) {
                    mTextInputBirthDay.setError("Please select a valid birth date");
                    mTextInputBirthDay.setHintEnabled(true);
                    return;
                }


                Calendar oldestValidDate = Calendar.getInstance();
                oldestValidDate.add(Calendar.YEAR, -100);
                if (selectedDate.before(oldestValidDate)) {
                    mTextInputBirthDay.setError("Please select a valid birth date.");
                    mTextInputBirthDay.setHintEnabled(true);
                    return;
                }


                Calendar minimumValidDate = Calendar.getInstance();
                minimumValidDate.add(Calendar.YEAR, -5);
                if (selectedDate.after(minimumValidDate)) {
                    mTextInputBirthDay.setError("Selected date is too far in the past. Please select a valid birth date.");
                    mTextInputBirthDay.setHintEnabled(true);
                    return;
                }

                String birthDate = day + "/" + month + "/" + year;
                mEditTextBirthday.setText(birthDate);

                mTextInputBirthDay.setHintEnabled(false);
                mTextInputBirthDay.setError(null);
                mTextInputBirthDay.setHint("");

            }
        });
    }

    private void setIsLoggedIn(String email, String birthday) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.putString("birthday", birthday);
        editor.putBoolean("is_registered", true);
        editor.apply();
    }
}