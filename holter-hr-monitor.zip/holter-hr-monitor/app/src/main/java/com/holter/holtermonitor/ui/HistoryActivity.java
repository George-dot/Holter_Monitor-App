package com.holter.holtermonitor.ui;

import static com.holter.holtermonitor.utils.HolterMonitorConstants.PAGE_SIZE;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.holter.holtermonitor.R;

import com.holter.holtermonitor.adapter.HeartRateAdapter;
import com.holter.holtermonitor.adapter.HistoryPagerAdapter;
import com.holter.holtermonitor.db.entity.HeartRate;
import com.holter.holtermonitor.db.HeartRateDao;
import com.holter.holtermonitor.db.HeartRateDatabase;
import com.holter.holtermonitor.db.HeartRateDatabaseInstance;
import com.holter.holtermonitor.fragments.HeartRateFragment;

import java.util.List;
import java.util.Objects;

public class HistoryActivity extends BaseActivity {

    @Override
    int getContentViewId() {
        return R.layout.activity_history;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.item_history;
    }

    @Override
    void init() {
        Toolbar mToolbar = findViewById(R.id.history_app_bar);
        if (mToolbar != null) {
            setSupportActionBar(mToolbar);
            Objects.requireNonNull(getSupportActionBar()).setTitle("History");
        }

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager2 viewPager = findViewById(R.id.viewPager);

        HistoryPagerAdapter adapter = new HistoryPagerAdapter(this);
        viewPager.setAdapter(adapter);


        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("ECG");
                    break;
                case 1:
                    tab.setText("Heart Rate");

                    break;
            }
        }).attach();


    }
}