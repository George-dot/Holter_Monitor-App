package com.holter.holtermonitor.utils;

public class HolterMonitorConstants {
    public static final String PREFS_NAME = "holtermonitprefs";
    public static final String SERVER_URI = "tcp://broker.hivemq.com:1883";
    public static final String HEART_RHYTHM_SUBSCRIPTION = "ug/holter/heart_rhythm";
    public static final String PULSE_SUBSCRIPTION = "ug/holter/pulse";
    public static final int REQUEST_ENABLE_WIFI = 1;
    public static final int SIXTY_SECONDS = 60;
    public static final int MAX_HEART_RATE = 100;
    /**
     * <b>Resting</b>: User is idle (sitting or sleeping)
     **/
    public static final String RESTING = "resting";
    /**
     * <b>Normal Aerobics</b>: User is walking
     **/
    public static final String NORMAL_AEROBICS = "normal_aerobics";
    /**
     * <b>Hard Aerobics</b>: User is running, jogging, etc.
     **/
    public static final String HARD_AEROBICS = "hard_aerobics";
    public static final double RESTING_LEVEL = 0.45;
    public static final double NORMAL_AEROBICS_LEVEL = 0.65;
    public static final double HARD_AEROBICS_LEVEL = 0.80;
    public static final double DEFAULT_LEVEL = 0.40;
    public static final int PAGE_SIZE = 20;
}
